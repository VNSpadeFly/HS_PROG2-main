# javaShooterWS19 (tentative version for Prog2 SS21)
Programmed by Alexander Gepperth, HAW Fulda

Three games working: PacmanGame, BreakoutGame, SpaceInvadersGame

Run with (under Linux): source run.bash PacmanGame|BreakoutGame|SpaceInvadersGame

or integrate in IDE, of course.



