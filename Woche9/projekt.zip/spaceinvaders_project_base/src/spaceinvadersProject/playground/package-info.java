/**
 * The package javashooter.playground contains all classes implementing and describing game levels. Main class
 * to be subclassed here: {@link javashooter.playground.Playground}. A notable sublass that is already
 * implelented is {@link playground.SpaceInvadersLevel}, showing an example of how to subclass
 * {@link javashooter.playground.Playground},
 */
package spaceinvadersProject.playground;
